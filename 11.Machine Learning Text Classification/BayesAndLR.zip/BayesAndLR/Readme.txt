Read Me:

1.The execution should be performed on Eclipse.

2.In Main.java line 20; you can set variable removeStopWords = true/false; default value is true;

3.In LogisticRegression.java line 15; you can set value of λ(PENALTY); default value is 0.01; 

4.The accuracy could be printed out.

