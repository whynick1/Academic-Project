package id3;

@SuppressWarnings("serial")
public class InvalidHeuristicException extends Exception {
	public InvalidHeuristicException(String message) {
		super(message);
	}
}
